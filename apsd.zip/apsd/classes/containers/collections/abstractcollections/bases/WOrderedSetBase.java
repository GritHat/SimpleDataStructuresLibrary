package apsd.classes.containers.collections.abstractcollections.bases;

import apsd.classes.containers.collections.abstractcollections.WOrderedSet;
import apsd.classes.utilities.Box;
import apsd.interfaces.containers.base.IterableContainer;
import apsd.interfaces.containers.collections.OrderedSet;
import apsd.interfaces.containers.collections.SortedChain;
import apsd.interfaces.containers.iterators.ForwardIterator;

/** Object: Abstract wrapper set base implementation via chain. */
abstract public class WOrderedSetBase<Data extends Comparable<? super Data>, Chn extends SortedChain<Data>> extends WSetBase<Data, Chn> implements OrderedSet<Data> {

  protected WOrderedSetBase() {
    super();
  }

  /* ************************************************************************ */
  /* Override specific member functions from IterableContainer                */
  /* ************************************************************************ */

  @Override
  public boolean IsEqual(IterableContainer<Data> con) {
    if (con == null) return false;
    if (con == this) return true;
    if (this.Size().compareTo(con.Size()) != 0) return false;
    Box<Boolean> isEqual = new Box<>(true);
    con.FIterator().ForEachForward(dat -> {
      if (!this.chn.Exists(dat)) {
        isEqual.Set(false);
        return true; // Stop iteration
      }
      return false; // Continue iteration
    });
    return isEqual.Get();
  }

  public boolean IsEqual(WOrderedSet<Data> set) {
    if (set == null) return false;
    if (set == this) return true;
    if (this.Size().compareTo(set.Size()) != 0) return false;
    Box<Boolean> isEqual = new Box<>(true);
    ForwardIterator<Data> it = this.FIterator();
    ForwardIterator<Data> setIt = set.FIterator();
    while (it.IsValid() && setIt.IsValid()) {
      Data dat1 = it.GetCurrent();
      Data dat2 = setIt.GetCurrent();
      if (dat1.compareTo(dat2) != 0) {
        isEqual.Set(false);
        break;
      }
      it.Next();
      setIt.Next();
    }
    return isEqual.Get();
  }

  @Override
  public boolean Exists(Data dat) {
    if (dat == null) return false;
    return chn.Exists(dat);
  }

  /* ************************************************************************ */
  /* Override specific member functions from OrderedSet                       */
  /* ************************************************************************ */

  @Override
  public Data Min() {
    return chn.Min();
  }

  @Override
  public Data Max() {
    return chn.Max();
  }

  @Override
  public void RemoveMin() {
    chn.RemoveMin();
  }

  @Override
  public void RemoveMax() {
    chn.RemoveMax();
  }

  @Override
  public Data MinNRemove() {
    return chn.MinNRemove();
  }

  @Override
  public Data MaxNRemove() {
    return chn.MaxNRemove();
  }

  @Override
  public Data Predecessor(Data dat) {
    if (dat == null) return null;
    return chn.Predecessor(dat);
  }

  @Override
  public Data Successor(Data dat) {
    if (dat == null) return null;
    return chn.Successor(dat);
  }

  @Override
  public void RemovePredecessor(Data dat) {
    if (dat == null) return;
    chn.RemovePredecessor(dat);
  }

  @Override
  public void RemoveSuccessor(Data dat) {
    if (dat == null) return;
    chn.RemoveSuccessor(dat);
  }

  @Override
  public Data PredecessorNRemove(Data dat) {
    if (dat == null) return null;
    return chn.PredecessorNRemove(dat);
  }

  @Override
  public Data SuccessorNRemove(Data dat) {
    if (dat == null) return null;
    return chn.SuccessorNRemove(dat);
  }

}
