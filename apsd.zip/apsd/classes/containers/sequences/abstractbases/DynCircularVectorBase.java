package apsd.classes.containers.sequences.abstractbases;

import apsd.classes.utilities.Natural;
import apsd.interfaces.containers.sequences.DynVector;

/** Object: Abstract dynamic circular vector base implementation. */
abstract public class DynCircularVectorBase<Data> extends CircularVectorBase<Data> implements DynVector<Data> { // Must extend CircularVectorBase and implement DynVector

  protected long size = 0L;

  // DynCircularVectorBase
  protected DynCircularVectorBase(Natural capacity) {
    super(capacity);
  }

  @Override
  protected void ArrayAlloc(Natural newsize) {
    super.ArrayAlloc(newsize);
    this.size = 0L;
  }

  /* ************************************************************************ */
  /* Override specific member functions from Container                        */
  /* ************************************************************************ */

  // ...
  @Override
  public Natural Size() {
    return Natural.Of(this.size);
  }

  /* ************************************************************************ */
  /* Override specific member functions from ClearableContainer               */
  /* ************************************************************************ */

  // ...
  @Override
  public void Clear() {
    super.Clear();
    this.size = 0L;
  }

  /* ************************************************************************ */
  /* Override specific member functions from ReallocableContainer             */
  /* ************************************************************************ */

  // ...
  @Override
  public void Realloc(Natural newcapacity) {
    if (newcapacity == null) return;
    long oldsize = Size().ToLong();
    super.Realloc(newcapacity);
    this.size = Math.min(oldsize, newcapacity.ToLong());
  }

  /* ************************************************************************ */
  /* Override specific member functions from ResizableContainer               */
  /* ************************************************************************ */

  // ...
  @Override
  public void Expand(Natural additionalSize) {
    if (additionalSize == null) return;
    long newSize = this.size + additionalSize.ToLong();
    if (newSize > Capacity().ToLong()) Grow(additionalSize);
    this.size = newSize;
  }

  @Override
  public void Reduce(Natural reductionSize) {
    if (reductionSize == null) return;
    if (reductionSize.ToLong() > this.size) throw new ArithmeticException("Underflow: reduction size exceeds current size!");
    Realing();
    this.size -= reductionSize.ToLong();
    if ((long)(THRESHOLD_FACTOR * SHRINK_FACTOR * Size().ToLong()) <= Capacity().ToLong()) Shrink();
  }

  /* ************************************************************************ */
  /* Specific member functions of Vector                                      */
  /* ************************************************************************ */

  // ...
  @Override
  public void ShiftLeft(Natural pos, Natural num) {
    super.ShiftLeft(pos, num);
    Reduce(num);
  }

  @Override
  public void ShiftRight(Natural pos, Natural num) {
    Expand(num);
    long idx = PositionToIndex(pos);
    long count = num.ToLong();
    long rdr = Size().ToLong() - 1 - count;;
    for (long wrt = Size().ToLong() - 1; rdr >= idx; rdr--, wrt--) {
      SetAt(GetAt(Natural.Of(rdr)), Natural.Of(wrt));
      SetAt(null, Natural.Of(rdr));
    }
    if (this.start > idx) {
      this.start = (this.start + count) % Size().ToLong();
    }
  }
}
