package apsd.interfaces.containers.sequences;

import apsd.classes.utilities.Natural;

/** Interface: Sequence con supporto all'inserimento di un dato tramite posizione. */
public interface InsertableAtSequence<Data> extends Sequence<Data> { // Must extend Sequence

  // InsertAt
  void InsertAt(Data data, Natural num);

  // InsertFirst
  default void InsertFirst(Data data) {
    if (data == null) return;
    InsertAt(data, new Natural(0));
  };

  // InsertLast
  default void InsertLast(Data data) {
    if (data == null) return;
    InsertAt(data, this.Size());
  };

}
