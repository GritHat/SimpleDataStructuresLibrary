package apsd.interfaces.containers.sequences;

import apsd.classes.utilities.Natural;

/** Interface: Sequence con supporto alla rimozione di un dato tramite posizione. */
public interface RemovableAtSequence<Data> extends Sequence<Data> { // Must extend Sequence

  // RemoveAt
  default void RemoveAt(Natural num) {
    AtNRemove(num);
  };
  // AtNRemove
  Data AtNRemove(Natural num);

  // RemoveFirst
  default void RemoveFirst() {
    if (this.Size().ToLong() == 0) return;
    AtNRemove(new Natural(0));
  };
  // FirstNRemove
  default Data FirstNRemove() {
    if (this.Size().ToLong() == 0) throw new IndexOutOfBoundsException("Sequence is empty.");
    return AtNRemove(new Natural(0));
  };

  // RemoveLast
  default void RemoveLast() {
    if (this.Size().ToLong() == 0) return;
    AtNRemove(this.Size().Decrement());
  };
  // LastNRemove
  default Data LastNRemove() {
    return AtNRemove(this.Size().Decrement());
  };

}
