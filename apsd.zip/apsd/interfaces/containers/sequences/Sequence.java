package apsd.interfaces.containers.sequences;

import apsd.classes.utilities.Natural;
import apsd.interfaces.containers.base.IterableContainer;
import apsd.interfaces.containers.iterators.ForwardIterator;

/** Interface: IterableContainer con supporto alla lettura e ricerca tramite posizione. */
public interface Sequence<Data> extends IterableContainer<Data> { // Must extend IterableContainer

  // GetAt
  default Data GetAt(Natural num) {
    if (num == null) throw new NullPointerException("Index out of bounds: Index is null Size: " + Size() + "!");  
    long idx = ExcIfOutOfBound(num);
    if (idx == this.Size().ToLong() - 1) return this.BIterator().DataNPrev();
    ForwardIterator<Data> it = this.FIterator();
    long currentIdx = 0;
    while (it.IsValid()) {
      Data value = it.DataNNext();
      if (currentIdx == idx) return value;
      currentIdx++;
    }
    throw new IndexOutOfBoundsException("Index out of bounds: " + idx + "; Size: " + Size() + "!");
  };

  // GetFirst
  default Data GetFirst() {
    return GetAt(Natural.ZERO);
  };
  // GetLast
  default Data GetLast() {
    if (this.Size().ToLong() == 0L) throw new IndexOutOfBoundsException("GetLast: Cannot get last element of an empty sequence!");
    return GetAt(Natural.Of(this.Size().ToLong() - 1));
  };

  // Search
  default Natural Search(Data value) {
    ForwardIterator<Data> it = this.FIterator();
    Natural idx = new Natural(0);
    while (it.IsValid()) {
      Data currentValue = it.DataNNext();
      if ((currentValue == null && value == null) ||
          (currentValue != null && currentValue.equals(value))) {
        return idx;
      }
      idx = idx.Increment();
    }
    return null;
  };

  // IsInBound
  default boolean IsInBound(Natural num) {
    if (num == null) throw new NullPointerException("Natural number cannot be null!");
    long idx = num.ToLong();
    return idx < Size().ToLong();
  };

  default long ExcIfOutOfBound(Natural num) {
    if (num == null) throw new NullPointerException("Natural number cannot be null!");
    long idx = num.ToLong();
    if (idx >= Size().ToLong()) throw new IndexOutOfBoundsException("Index out of bounds: " + idx + "; Size: " + Size() + "!");
    return idx;
  }

  // SubSequence
  Sequence<Data> SubSequence(Natural from, Natural to);
}
