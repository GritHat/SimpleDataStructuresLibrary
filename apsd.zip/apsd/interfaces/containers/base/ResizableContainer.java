package apsd.interfaces.containers.base;

import apsd.classes.utilities.Natural;

// import apsd.classes.utilities.Natural;

/** Interface: ReallocableContainer che è espandibile e riducibile. */
public interface ResizableContainer extends ReallocableContainer { // Must extend ReallocableContainer

  double THRESHOLD_FACTOR = 2.0; // Must be strictly greater than 1.

  // Expand
  default void Expand() {
    Expand(Natural.ONE);
  }

  void Expand(Natural size);

  // Reduce

  default void Reduce() {
    Reduce(Natural.ONE);
  }

  void Reduce(Natural size);


  /* ************************************************************************ */
  /* Override specific member functions from Container                        */
  /* ************************************************************************ */

  // ...

  /* ************************************************************************ */
  /* Override specific member functions from ReallocableContainer             */
  /* ************************************************************************ */

  @Override
  Natural Size();

  // @Override
  // default void Grow(Natural additionalSize) {
  //   if (this.Size().ToLong() + additionalSize.ToLong() > this.Capacity().ToLong())
  //     ReallocableContainer.super.Grow(additionalSize);
  // }

  // @Override
  // default void Shrink() {
  //   if ((long) (THRESHOLD_FACTOR * SHRINK_FACTOR * Size().ToLong()) <= Capacity().ToLong()) ReallocableContainer.super.Shrink();
  // }

}
